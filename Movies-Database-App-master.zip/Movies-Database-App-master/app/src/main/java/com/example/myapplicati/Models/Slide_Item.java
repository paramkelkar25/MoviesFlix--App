package com.example.myapplicati.Models;

public class Slide_Item {
    int image;

    public Slide_Item(int image) {
        this.image = image;
    }
    public int getImage() {
        return image;
    }
    public void setImage(int image) {
        this.image = image;
    }
}

package com.example.myapplicati.Models;

public class moviesmodel {
    public moviesmodel(int pic) {
        this.pic = pic;
    }

    int pic;

    public int getPic() {
        return pic;
    }
    public void setPic(int pic) {
        this.pic = pic;
    }
}

